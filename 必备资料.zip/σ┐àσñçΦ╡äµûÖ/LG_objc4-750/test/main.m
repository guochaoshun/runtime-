//
//  main.m
//  test
//
//  Created by H on 2019/3/5.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    Person * p = [Person alloc];
    return 0;
}
